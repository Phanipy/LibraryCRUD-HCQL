package demo;

import javax.persistence.*;

@Entity
public class Library {
	@Id
	private int bno;
	public int getBno() {
		return bno;
	}
	public void setBno(int bno) {
		this.bno = bno;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public int getPages() {
		return pages;
	}
	public void setPages(int pages) {
		this.pages = pages;
	}
	private String bname;
	private int pages;
	@Override
	public String toString() {
		return "Library [bno=" + bno + ", bname=" + bname + ", pages=" + pages + "]";
	}

}
